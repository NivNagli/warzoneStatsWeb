const fetchPlayerData = async (platform, username) => {
    
    Url = buildUrlForPlayerApi(platform, username);
    if(Url === "invalid-platform") {  // צריך לזכור להתייחס למצב הזה @TODO 
        return {data: {error : platform + " is invalid-platform!"}};
        
    } 
    const res = await playerDataPullApi(Url);
    return res;
};

const buildUrlForPlayerApi = (platform, username) => {
    if(!platformValidatoion(platform)) {
        console.log("invalid platform recived need to solve that later, occur on 'buildUrl' method.");
        return "invalid-platform";
    }
    let fullUrl = "https://call-of-duty4.p.rapidapi.com/warzone?";
    fullUrl += "platform=" + platform + "&" + "gamertag=" + username;
    return fullUrl;
};

const platformValidatoion = (platform) => {
    platforms = ["psn", "battle", "xbl"];
    return platforms.includes(platform);
};

const playerDataPullApi = (validUrl) => {
    dataRequest =  axios.get(validUrl, {
        headers: {
            "x-rapidapi-host": "call-of-duty4.p.rapidapi.com",
            "x-rapidapi-key": "b14307b3e4msh6be8713ea2388fap1c9dfejsn391d18f80338"
        }
    });
    return dataRequest;
};

// Until This point this is fetchPlayerData ----------------------------------------------

/* מטודות אלו יוכלו לעזור במהשך אם נרצה חיפוש יותר פרטני, מה שהן עושות זה שולפות את המידע לפי מספר מזהה של משחק */

// const fetchCommonMatches = async (matchIdArray) => {  // יש מצב שלא צריך את המטודה הזו בכלל
//     const matchesPromises = [];
//     for(let matchId of matchIdArray) {
//         matchesPromises.push(fetchMatchData(matchId));
//     }
//     const res = await Promise.all(matchesPromises);
//     // console.log(res);
//     return res;
// }

// const fetchMatchData = async (matchId) => {
//     matchUrl = buildUrlForMatchApi(matchId);
//     const matchData = await axios.get(matchUrl);
//     return matchData;
// };

// const buildUrlForMatchApi = (matchId) => {
//     let matchUrl = "https://www.callofduty.com/api/papi-client/crm/cod/v2/title/mw/platform/battle/fullMatch/wz/"
//     matchUrl += matchId + "/it";
//     return matchUrl;
// };

// Until this stage we fetch the general data structures now we will need to make function to work on them ------

/* The next functions are going to serve us to get the exact information about the selected players */

const funcs = [getTotalKills,getTotalDeaths,getTotalAssists, getTotalDamageDone,getTotalDamageTaken, getTotalRevives, getTotalGulagKills];

const findCommonGamesData = async (platformsList, playerNamesList) => {
    const promiseBarrier = [];
    if(platformsList.length === 0 || platformsList.length !== playerNamesList.length) {
        throw (new Error("recived empty array in 'findCommonGamesData' method!"));  // with the boolean we will indicate if we need to reload this option.
    }

    for(let i = 0; i < playerNamesList.length ; i++ ) {
        promiseBarrier.push(fetchPlayerData(platformsList[i], playerNamesList[i]));  // using barrier because we want parallel extracting
    }

    const playerDataArray = await Promise.all(promiseBarrier);  // שירוצו במקביל הבקשות
    findApiErrors(playerDataArray);

    const commonMatchIDArray = commonMatchesIDList(...playerDataArray);  // שליפת מספרים מזהים של משחקים משותפים
    
    if(commonMatchIDArray.length === 0){
        throw(new Error("The users dont have common matches in the last 20 games!"));  // case of nothing to render.
    } 

    const commonGamesData = getCommonGameData(playerDataArray,commonMatchIDArray); // here pull the common games general data.
    const commonGamesStats = [];  // our result, will contain objects with the common games stats for each player.
    commonGamesData.forEach( (gameData) => {
        commonGamesStats.push(getStats(gameData, ...funcs));  // pull the stats we want to save.
    });
    console.log(commonGamesData);
    return commonGamesData;

}

const findAllGamesData = async (platformsList, playerNamesList) => {
    const promiseBarrier = [];
    if(platformsList.length === 0 || platformsList.length !== playerNamesList.length) {
        throw (new Error("recived empty array in 'findAllGamesData' method!"));  // with the boolean we will indicate if we need to reload this option.
    }
    for(let i = 0; i < playerNamesList.length ; i++ ) {
        promiseBarrier.push(fetchPlayerData(platformsList[i], playerNamesList[i]));  // using barrier because we want parallel extracting
    }
    const playerDataArray = await Promise.all(promiseBarrier);  // שירוצו במקביל הבקשות
    findApiErrors(playerDataArray);

    gamesData = [];
    const allGamesStats = [];
    
    for(let playerData of playerDataArray) {
        gamesData.push(getAllMatchesStats(getMatches(playerData)));      
    }

    gamesData.forEach( (gameData, index) => {
        allGamesStats.push(getStats(gameData, ...funcs));
    });
    console.log(allGamesStats);
    return allGamesStats;
};

const findApiErrors = (playerDataArray) => {
    for(let playerData of playerDataArray) {
        if(pullTester(playerData) ) {
            throw (new Error(playerData.data.error));
        }
    }
};

const pullTester = (playerData) => {
    if(playerData.data.error) {
        return true;
    }
    return false;
};



