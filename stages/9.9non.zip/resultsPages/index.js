const stats = JSON.parse(localStorage.getItem('result'));
sortGameData(0,stats);
console.log(stats);


const createResultPage = (statsArray) => {
    const container = document.querySelector(".results__container");
    const statsKeys = ["kills", "deaths", "assists", "damageDone", "damageTaken", "revives", "gulagKills"];
    for (let i = 0; i < statsKeys.length; i++) {
        let leaderBoardDiv = document.createElement('div');
        leaderBoardDiv.classList.add("leaderboard");
        let h2Header = document.createElement('h2');
        h2Header.innerHTML = statsKeys[i] +" :";
        leaderBoardDiv.appendChild(h2Header);
        for (let j = 0; j < statsArray.length; j++) {
            let contentDiv = document.createElement('div');
            contentDiv.classList.add("content1");
            sortGameData(i, statsArray);
            resArray = [...statsArray].reverse();
            contentDiv.innerHTML = `<h1>${j + 1}) ${resArray[j]["username"]} : ${resArray[j][i][statsKeys[i]]}</h1>`;
            leaderBoardDiv.appendChild(contentDiv);
        }
        container.appendChild(leaderBoardDiv);
    }
}



createResultPage(stats);