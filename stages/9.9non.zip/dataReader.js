// This file will serve us to work on the objects that we pull from the Api's

//// -------------------------------------- This is useful function but not to the current stage.

// const findPlayersStats = (matchArray,playersNames) => {  

//     results = {}; //'fetchCommonMatches' המטודה הזו תקבל את המערך של האובייקטים של המשחקים מהמטודה 

//     for(let match of matchArray) {
//         for(let user of match.data.data.allPlayers) {
//             let username = user.player.username;
//             if(playersNames.includes(username)) {
//                 if(username in results) {
//                     results[username].push(user.playerStats);
//                 }
//                 else {
//                     results[username] = [user.playerStats];
//                 }
//             }
//         }
//     }
//     console.log(results);
//     return results;
// }



// // ---------------------------------------- relevent to current versrion: -------------------------------

const getCommonMatchesStats = (playerData, commonMatchesIdArray) => {
    // יש בידנו את המספרים של המשחקים המשותפים אנחנו בודקים אם המשחק שאנחנו עוברים עליו הוא אחד מהם אם כן נצרף אותו לנתונים
    result = [];
    for(let match of playerData) {
        if(commonMatchesIdArray.includes(match.matchID)) {
            result.push(match.playerStats);
        }
    }
    return result;
}

const getAllMatchesStats = (playerData) => {
    result = [];
    for(let match of playerData) {
        result.push(match.playerStats);
    }
    return result;
}

const commonMatchesIDList = (...playersData) => {
    const allMatches = [];
    let index = 0;
    for(let playerData of playersData) {
        allMatches.push([]);
        for(let match of getMatches(playerData)) {
            allMatches[index].push(match.matchID);
        }
        index++;
    }
    return filterMatches(allMatches);
};

const getMatches = (playerData)=> {
    return playerData.data.data.matches;
};

const filterMatches = (matchIdList) => {
    // מוצא מספרים של משחקים משותפים על ידי חיתוך בניהם
    return matchIdList.reduce((a, b) => a.filter(c => b.includes(c))); 
};

const getCommonGameData = (playerDataArray,commonMatchIDArray) => {
    commonGameData = [];
    for(let playerData of playerDataArray) {
        let playerMatches = getMatches(playerData);
        commonGameData.push(getCommonMatchesStats(playerMatches,commonMatchIDArray));
    }
    return commonGameData;
}

// ===== Spesefic data collector:

const getAvgKd = (matchesStats) => {
    let kd = 0;
    for(let match of matchesStats) {
        kd += match.kdRatio;
    }
    return {kdRatio : (kd / matchesStats.length)};
};

const getTotalDamageDone = (matchesStats) => {
    let damageDone = 0;
    for(let match of matchesStats) {
        damageDone += match.damageDone;
    }
    return {damageDone : damageDone};
};

const getTotalKills = (matchesStats) => {
    let kills = 0;
    for(let match of matchesStats) {
        kills += match.kills;
    }
    return {kills : kills};
};

const getTotalRevives = (matchesStats) => {
    let revives = 0;
    for(let match of matchesStats) {
        revives += match.objectiveReviver;
    }
    return {revives : revives};
};

const getTotalAssists = (matchesStats) => {
    let assists = 0;
    for(let match of matchesStats) {
        assists += match.assists;
    }
    return {assists : assists};
};

const getTotalDamageTaken = (matchesStats) => {
    let damageTaken = 0;
    for(let match of matchesStats) {
        damageTaken += match.damageTaken;
    }
    return {damageTaken : damageTaken};
};

const getTotalGulagKills = (matchesStats) => {
    let gulagKills = 0;
    for(let match of matchesStats) {
        gulagKills += match.gulagKills;
    }
    return {gulagKills : gulagKills};
};

const getTotalDeaths = (matchesStats) => {
    let deaths = 0;
    for(let match of matchesStats) {
        deaths += match.deaths;
    }
    return {deaths : deaths};
};

const getStats = (matchesStats, ...dataExtractors) => {
    let data = [];
    for(let func of dataExtractors) {
        data.push(func(matchesStats));
    }
    return {...data};
}

const sortGameData = (compareKeyIndex, gamesStats) => {
    /* sort the statsARray according to the spesefic stats that sit in some index
    that will help us to sort the stats array stat by stat because they sit in array which each item is object */
    gamesStats.sort( (x, y) => {
        return parseFloat(Object.values(x[compareKeyIndex])[0]) - parseFloat(Object.values(y[compareKeyIndex])[0]);});
    return gamesStats;
}

const addUsernameForStats = (userNamesArray,gameStats) => {
    for(let i = 0 ; i < userNamesArray.length ; i++) {
        gameStats[i].username = userNamesArray[i];
    }
}







