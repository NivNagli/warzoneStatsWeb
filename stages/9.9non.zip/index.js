// ----------------- advanced findCommonGamesDatas --------------------------


// findCommonGamesData(["psn" , "psn"], ["Mini_Niva" , "INBAR_GAB"])
// .then( 
//     (r) => {
//         if(r) {
//             console.log(r);
//             // now do what you want with r 
//         }
//         else{
//             console.log("in case of failure we will be here!");
//         }
//     }).catch( e => {console.log(e)});

// Find all games Data!

// const playersNames = ["Mini_Niv" , "INBAR_GAB"];
// const platformsNames = ["psn" , "psn"];

// findAllGamesData(platformsNames, playersNames)
//     .then(
//         (r) => {
//             if (r) {
//                 // console.log(r);
//                 addUsernameForStats(playersNames, r);
//                 console.log(r[0][0]["kills"]);
//                 console.log(r[0]["username"]);
                

//                 // now do what you want with r 
//             }
//             else {
//                 console.log("in case of failure we will be here!");
//             }
//         }).catch(e => { console.log(e) });


// fetchMatchData("17741912956438829840");

// data.error === "User not found!" || User profile is private! || invalid-platform!

// // ------------------------------------------------------------------------------------------------------------
// // ------------------------------------------------------------------------------------------------------------
/* Until this stage i did the data pulling, that didnt end yet we need to build something arount this method's to be more,
general and also re-usable but we need for that the front-end design.
Also! we need to handle the Errors above the lines that above this text and to consider that in the webpage that user can,
enter some invalid information or he can have a private profile that not allowed to share data!. */


// // From now we have to current frontend code for the main page, now need to work on the route in case we got valid information.

createSearchPage({
    mainContainerClassName: "player-search-form", innerSelectContainerID: "number-of-players",
    onSelectMethod: (e) => {
        document.querySelector(".players-data__container").innerHTML = '';
        // console.log(e.target.options[e.target.selectedIndex].value);
        // console.log("0" === e.target.options[e.target.selectedIndex].value);
        let numberOfUsers = Math.floor(e.target.options[e.target.selectedIndex].value);
        if (!numberOfUsers) {  // if the user didnt select any number of users from the players select
            return;
        }
        buildUserForms(numberOfUsers);
        onSearchSelect();
    }
});

const buildUserForms = (formNum) => {
    for (let i = 0; i < formNum; i++) {
        let div = document.createElement('div');
        div.innerHTML = dataForm;
        // console.log(div);
        document.querySelector(".players-data__container").appendChild(div);
    }
    document.querySelector(".players-data__container").appendChild(buildSearchButton());
};

const dataForm = `        <div class="player-data__info"> 
<div class="select is-rounded select is-small">
  <select class="platform-selector">
    <option value="0" class="select-option-user">Select Platform</option>
    <option value="1" class="select-option-user">Playstation</option>
    <option value="2" class="select-option-user">Xbox-Live</option>
    <option value="3" class="select-option-user">Battle.Net</option>
  </select>
</div>
<input class="input is-rounded username-input" type="text" placeholder="username">
</div>`;

const buildSearchButton = () => {
    let button = document.createElement('button');
    button.classList.add("button");
    button.classList.add("is-danger");
    button.classList.add("is-rounded");
    button.innerHTML = "Search";
    button.addEventListener('click', onSearchSelect);
    return button;
};

const onSearchSelect = () => {
    const platformsKeys = { "Playstation": "psn", "Xbox-Live": "xbl", "Battle.Net": "battle" };
    const usernames = [];
    const platforms = [];
    const allUserSelects = document.querySelectorAll(".platform-selector");
    const allUserInputs = document.querySelectorAll(".username-input");
    for (let select of allUserSelects) {
        if (!select.options.selectedIndex) {
            console.log("false1 ['onSearchSelect' methd index.js]"); // need to handle a error over here, ignore for now
            return false;
        }
        platforms.push(platformsKeys[select.options[select.options.selectedIndex].text]);
    }

    for (let input of allUserInputs) {
        if (input.value === "") {
            console.log("false2 ['onSearchSelect' methd index.js]");
            return false;
        }
        usernames.push(input.value);
    }

    console.log(platforms);
    console.log(usernames);

    findAllGamesData(platforms, usernames)
        .then(
            (result) => {
                if (result) {
                    addUsernameForStats(usernames, result);
                    localStorage.setItem("result",JSON.stringify(result));
                    window.location.href = "/resultsPages/result.html";
                    console.log(result);
                }
                else {
                    console.log("in case of failure we will be here!");
                }
            }).catch(e => { console.log(e) });
};

// const createResultPage = (statsArray) => {
//     for(let i = 0 ; i < 8 ; i ++) {
//         for(let j = 0 ; j < statsArray.length ; j ++) {

//         }
//     }
// }



