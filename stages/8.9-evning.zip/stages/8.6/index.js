// ----------------- advanced tests --------------------------

// const funcs = [getAvgKd, getTotalDamageDone, getTotalRevives, getTotalAssists, getTotalDamageTaken, getTotalGulagKills, getTotalDeaths,getTotalKills];

// const test = async () => {
//     const res1 =  fetchPlayerData("psn", "Mini_Niv");
//     const res2 =  fetchPlayerData("psn", "mp3il");
//     const res3 =  fetchPlayerData("psn", "INBAR_GAB");
//     const result = await Promise.all([res1, res2, res3]);  // שירוצו במקביל הבקשות

//     const commonMatchIDArray = commonMatchesIDList(...result);  // שליפת מספרים מזהים של משחקים משותפים


//     player1Stats = getCommonMatchesStats(getMatches(result[0]),commonMatchIDArray); // שליפת מידע על המשחקים המשותפים
//     player2Stats = getCommonMatchesStats(getMatches(result[1]),commonMatchIDArray); // בעזרת מספר מזהה
//     player3Stats = getCommonMatchesStats(getMatches(result[2]),commonMatchIDArray); 
//     console.log(player1Stats);  
//     console.log(player2Stats);  
//     console.log(player3Stats);
//     console.log(getStats(player1Stats, ...funcs));


// }
// test();


// fetchMatchData("17741912956438829840");

// data.error === "User not found!" || User profile is private! || invalid-platform!

// // ------------------------------------------------------------------------------------------------------------
// // ------------------------------------------------------------------------------------------------------------
/* Until this stage i did the data pulling, that didnt end yet we need to build something arount this method's to be more,
general and also re-usable but we need for that the front-end design.
Also! we need to handle the Errors above the lines that above this text and to consider that in the webpage that user can,
enter some invalid information or he can have a private profile that not allowed to share data!. */


// getting the selected option from our palyer-selector
// const numOfPlayers = document.querySelector(".players-selector__container").querySelector("select");
// numOfPlayers.addEventListener('change', (e)=> {
//     numOfPlayers.classList.add("is-focused");
//     console.log(e.target.options[e.target.selectedIndex].value);
// });  

// console.log(numOfPlayers);

createSearchPage({
    mainContainerClassName: "player-search-form", innerSelectContainerID: "number-of-players",
    onSelectMethod: (e) => {
        document.querySelector(".players-data__container").innerHTML = '';
        // console.log(e.target.options[e.target.selectedIndex].value);
        // console.log("0" === e.target.options[e.target.selectedIndex].value);
        let selectValue = Math.floor(e.target.options[e.target.selectedIndex].value);
        if (!selectValue) {
            return;
        }
        buildUserForms(selectValue);
        informationExists();
    }
});

const buildUserForms = (formNum) => {
    for(let i = 0 ; i < formNum ; i++) {
        let div = document.createElement('div');
        div.innerHTML = dataForm;
        // console.log(div);
        document.querySelector(".players-data__container").appendChild(div);
    }
    document.querySelector(".players-data__container").appendChild(buildSearchButton());
};

const dataForm = `        <div class="player-data__info"> 
<div class="select is-rounded select is-small">
  <select class="platform-selector">
    <option value="0" class="select-option-user">Select Platform</option>
    <option value="1" class="select-option-user">Playstaion</option>
    <option value="2" class="select-option-user">Xbox-Live</option>
    <option value="3" class="select-option-user">Battle.Net</option>
  </select>
</div>
<input class="input is-rounded username-input" type="text" placeholder="username">
</div>`;

const buildSearchButton = () => {
    let button = document.createElement('button');
    button.classList.add("button");
    button.classList.add("is-danger");
    button.classList.add("is-rounded");
    button.innerHTML= "Search";
    button.addEventListener('click', informationExists);
    return button;
};

const informationExists = () => {
    const allUserSelects = document.querySelectorAll(".platform-selector");
    const allUserInputs = document.querySelectorAll(".username-input");
    for(let select of allUserSelects) {
        if(!select.options.selectedIndex) {
            console.log("false1");
            return false;
        }
    }

    for(let input of allUserInputs) {
        if(input.value === ""){
            console.log("false2");
            return false;
        }
    }
    console.log(allUserInputs[0].value);
};


