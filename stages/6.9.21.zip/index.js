// ----------------- advanced tests --------------------------


const test = async () => {
    const res1 =  fetchPlayerData("psn", "Mini_Niv");
    const res2 =  fetchPlayerData("psn", "mp3il");
    const res3 =  fetchPlayerData("psn", "INBAR_GAB");
    const result = await Promise.all([res1, res2, res3]);  // שירוצו במקביל הבקשות
    const commonMatchIDArray = commonMatchesIDList(...result);  // שליפת מספרים מזהים של משחקים משותפים

    // const commonMatches = await fetchCommonMatches(commonMatchIDArray);
    // console.log(commonMatches);

    console.log(getCommonMatchesStats(result[0].data.data.matches,commonMatchIDArray));  // שליפת מידע על המשחקים המשותפים
    console.log(getCommonMatchesStats(result[1].data.data.matches,commonMatchIDArray));  // בעזרת מספר מזהה
    console.log(getCommonMatchesStats(result[2].data.data.matches,commonMatchIDArray));

}
test();


// fetchMatchData("17741912956438829840");