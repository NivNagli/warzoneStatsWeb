// var options = {
//   method: 'GET',
//   url: 'https://call-of-duty4.p.rapidapi.com/warzone',
//   params: {platform: 'battle', gamertag: 'Mini_Niv'},
//   headers: {
//     'x-rapidapi-host': 'call-of-duty4.p.rapidapi.com',
//     'x-rapidapi-key': 'b14307b3e4msh6be8713ea2388fap1c9dfejsn391d18f80338'
//   }
// };

// axios.request(options).then(function (response) {
// 	console.log(response.data);
// }).catch(function (error) {
// 	console.error(error);
// });

// try {
//     const response = await axios.get("http://https://call-of-duty4.p.rapidapi.com/warzone.omdbapi.com/", { // the url will be generated into new one with the two fields be supply.
//     params: {
//         apikey: "b14307b3e4msh6be8713ea2388fap1c9dfejsn391d18f80338", // the apikey we generate through the website
//         s: "avengers" // in the api manual there is a 's' parameter for the movie title we search for.
//     }
// });
// console.log(response.data); 
// }

// fetch("https://call-of-duty4.p.rapidapi.com/warzone?platform=playstaion&gamertag=Mini_Niv", {
// 	"method": "GET",
// 	"headers": {
// 		"x-rapidapi-host": "call-of-duty4.p.rapidapi.com",
// 		"x-rapidapi-key": "b14307b3e4msh6be8713ea2388fap1c9dfejsn391d18f80338"
// 	}
// })
// .then(response => {
//     let rs = response.body;
// 	console.log(response.body);
// })
// .catch(err => {
// 	console.error(err);
// });

// fetch("https://call-of-duty4.p.rapidapi.com/warzone?platform=playstaion&gamertag=Mini_Niv", {
// 	"method": "GET",
// 	"headers": {
// 		"x-rapidapi-host": "call-of-duty4.p.rapidapi.com",
// 		"x-rapidapi-key": "b14307b3e4msh6be8713ea2388fap1c9dfejsn391d18f80338"
// 	}
// })
// .then(response => response.body)
// .then(rb => {
//   const reader = rb.getReader();

//   return new ReadableStream({
//     start(controller) {
//       // The following function handles each data chunk
//       function push() {
//         // "done" is a Boolean and value a "Uint8Array"
//         reader.read().then( ({done, value}) => {
//           // If there is no more data to read
//           if (done) {
//             console.log('done', done);
//             controller.close();
//             return;
//           }
//           // Get the data and send it to the browser via the controller
//           controller.enqueue(value);
//           // Check chunks by logging to the console
//           console.log(done, value);
//           push();
//         })
//       }

//       push();
//     }
//   });
// })
// .then(stream => {
//   // Respond with our stream
//   return new Response(stream, { headers: { "Content-Type": "text/html" } }).text();
// })
// .then(result => {
//   // Do things with result
//   console.log(result);
// });

// ------------------------------- initial test ------------------------------------

// fetch("https://call-of-duty4.p.rapidapi.com/warzone?platform=psn&gamertag=Mini_Niv", {
// 	"method": "GET",
// 	"headers": {
// 		"x-rapidapi-host": "call-of-duty4.p.rapidapi.com",
// 		"x-rapidapi-key": "b14307b3e4msh6be8713ea2388fap1c9dfejsn391d18f80338"
// 	}
// })
// .then(response=>response.json())
// .then(data=>{ console.log(data); })
// .catch(err => {
// 	console.error(err);
// });

// -------------------------

// var myHeaders = new Headers();

// var requestOptions = {
//   method: 'GET',
//   redirect: 'follow'
// };

// fetch("https://www.callofduty.com/api/papi-client/crm/cod/v2/title/mw/platform/battle/fullMatch/wz/17741912956438829840/it", requestOptions)
// .then(response=>response.json())
// .then(data=>{ console.log(data); });