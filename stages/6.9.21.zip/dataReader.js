// This file will serve us to work on the objects that we pull from the Api's

//// -------------------------------------- This is useful function but not to the current stage.

// const findPlayersStats = (matchArray,playersNames) => {  

//     results = {}; //'fetchCommonMatches' המטודה הזו תקבל את המערך של האובייקטים של המשחקים מהמטודה 

//     for(let match of matchArray) {
//         for(let user of match.data.data.allPlayers) {
//             let username = user.player.username;
//             if(playersNames.includes(username)) {
//                 if(username in results) {
//                     results[username].push(user.playerStats);
//                 }
//                 else {
//                     results[username] = [user.playerStats];
//                 }
//             }
//         }
//     }
//     console.log(results);
//     return results;
// }



// // ---------------------------------------- relevent to current versrion: -------------------------------

const commonMatchesIDList = (...playersData) => {
    const allMatches = [];
    let index = 0;
    for(let playerData of playersData) {
        allMatches.push([]);
        for(let match of playerData.data.data.matches) {
            allMatches[index].push(match.matchID);
        }
        index++;
    }
    res = allMatches.reduce((a, b) => a.filter(c => b.includes(c))); // מוצא מספרים של משחקים משותפים על ידי חיתוך בניהם
    return res;
}

const getCommonMatchesStats = (playerData, commonMatchesIdArray) => {
    // יש בידנו את המספרים של המשחקים המשותפים אנחנו בודקים אם המשחק שאנחנו עוברים עליו הוא אחד מהם אם כן נצרף אותו לנתונים
    result = [];
    for(let match of playerData) {
        if(commonMatchesIdArray.includes(match.matchID)) {
            result.push(match.playerStats);
        }
    }
    return result;
}