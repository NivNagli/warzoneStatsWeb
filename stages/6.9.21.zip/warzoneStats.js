const fetchPlayerData = async (platform, username) => {
    
    Url = buildUrlForPlayerApi(platform, username);
    if(Url === "invalid-platform") {  // צריך לזכור להתייחס למצב הזה @TODO 
        return {data: "invalid platform!"};
        
    } 
    const res = await playerDataPullApi(Url);
    return res;
};

const buildUrlForPlayerApi = (platform, username) => {
    if(!platformValidatoion(platform)) {
        console.log("invalid platform recived need to solve that later, occur on 'buildUrl' method.");
        return "invalid-platform";
    }
    let fullUrl = "https://call-of-duty4.p.rapidapi.com/warzone?";
    fullUrl += "platform=" + platform + "&" + "gamertag=" + username;
    return fullUrl;
};

const platformValidatoion = (platform) => {
    platforms = ["psn", "battle", "xbl"];
    return platforms.includes(platform);
};

const playerDataPullApi = (validUrl) => {
    dataRequest =  axios.get(validUrl, {
        headers: {
            "x-rapidapi-host": "call-of-duty4.p.rapidapi.com",
            "x-rapidapi-key": "b14307b3e4msh6be8713ea2388fap1c9dfejsn391d18f80338"
        }
    });
    return dataRequest;
};

// Until This point this is fetchPlayerData ----------------------------------------------

/* מטודות אלו יוכלו לעזור במהשך אם נרצה חיפוש יותר פרטני, מה שהן עושות זה שולפות את המידע לפי מספר מזהה של משחק */

// const fetchCommonMatches = async (matchIdArray) => {  // יש מצב שלא צריך את המטודה הזו בכלל
//     const matchesPromises = [];
//     for(let matchId of matchIdArray) {
//         matchesPromises.push(fetchMatchData(matchId));
//     }
//     const res = await Promise.all(matchesPromises);
//     // console.log(res);
//     return res;
// }

// const fetchMatchData = async (matchId) => {
//     matchUrl = buildUrlForMatchApi(matchId);
//     const matchData = await axios.get(matchUrl);
//     return matchData;
// }

// const buildUrlForMatchApi = (matchId) => {
//     let matchUrl = "https://www.callofduty.com/api/papi-client/crm/cod/v2/title/mw/platform/battle/fullMatch/wz/"
//     matchUrl += matchId + "/it";
//     return matchUrl;
// }

// Until this stage we fetch the general data structures now we will need to make function to work on them ------


